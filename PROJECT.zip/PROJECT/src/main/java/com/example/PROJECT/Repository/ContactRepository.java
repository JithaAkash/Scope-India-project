package com.example.PROJECT.Repository;

import org.springframework.stereotype.Repository;

@Repository
public interface ContactRepository {
}
